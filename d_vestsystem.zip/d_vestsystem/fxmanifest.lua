fx_version 'cerulean'
game 'gta5'

author 'D_Scripts'
version '1.0'

client_scripts {
    'client/main.lua',
    'config/config.lua'
}

server_script{
    'server/main.lua'
}

dependencies {
	'mysql-async',
	'd_notify'
}

