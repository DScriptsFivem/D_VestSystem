ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

ESX.RegisterUsableItem('light-vest', function (source)

    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem('light-vest', 1)

    TriggerClientEvent('d_vestsystem:light', source)

end)

ESX.RegisterUsableItem('normal-vest', function (source)

    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem('normal-vest', 1)

    TriggerClientEvent('d_vestsystem:normal', source)

end)

ESX.RegisterUsableItem('heavy-vest', function (source)

    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem('heavy-vest', 1)

    TriggerClientEvent('d_vestsystem:heavy', source)

end)