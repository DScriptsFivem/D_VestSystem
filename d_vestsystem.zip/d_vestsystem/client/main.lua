ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('d_vestsystem:light')
AddEventHandler('d_vestsystem:light', function()
	local lib, anim = 'anim@heists@narcotics@funding@gang_idle', 'gang_chatting_idle01'
	local playerPed = PlayerPedId()

	ESX.Streaming.RequestAnimDict(lib, function()
		TaskPlayAnim(playerPed, lib, anim, 8.0, -8.0, 6000, 0, 0, false, false, false)
		AddArmourToPed(playerPed,25)
		SetPedComponentVariation(GetPlayerPed(-1), 9, Config.vest, Config.vest2, 0)
        if Config.notifications == true then
            exports['d_notify']:sendNotify( Config.Title, Config.Message, 5000, 'success')
        end
	end)
end)

RegisterNetEvent('d_vestsystem:normal')
AddEventHandler('d_vestsystem:normal', function()
	local lib, anim = 'anim@heists@narcotics@funding@gang_idle', 'gang_chatting_idle01'
	local playerPed = PlayerPedId()

	ESX.Streaming.RequestAnimDict(lib, function()
		TaskPlayAnim(playerPed, lib, anim, 8.0, -8.0, 6000, 0, 0, false, false, false)
		AddArmourToPed(playerPed,50)
		SetPedComponentVariation(GetPlayerPed(-1), 9, Config.vest3, Config.vest4, 0)
        if Config.notifications == true then
            exports['d_notify']:sendNotify( Config.Title2, Config.Message2, 5000, 'success')
        end
	end)
end)

RegisterNetEvent('d_vestsystem:heavy')
AddEventHandler('d_vestsystem:heavy', function()
	local lib, anim = 'anim@heists@narcotics@funding@gang_idle', 'gang_chatting_idle01'
	local playerPed = PlayerPedId()

	ESX.Streaming.RequestAnimDict(lib, function()
		TaskPlayAnim(playerPed, lib, anim, 8.0, -8.0, 6000, 0, 0, false, false, false)
		AddArmourToPed(playerPed,100)
		SetPedComponentVariation(GetPlayerPed(-1), 9, Config.vest5, Config.vest6, 0)
        if Config.notifications == true then
            exports['d_notify']:sendNotify( Config.Title3, Config.Message3, 5000, 'success')
        end
	end)
end)



