INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
	('light-vest', 'Light-Vest', '20', '0', '1'),
	('normal-vest', 'Normal-Vest', '20', '0', '1'),
    ('heavy-vest', 'Heavy-Vest', '20', '0', '1')
;