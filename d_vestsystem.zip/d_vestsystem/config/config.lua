Config = {}

-- Light protective vest

Config.notifications = true

Config.Title = "D_Vestsystem" -- Message Title

Config.Message = "Light-Vest Successfully used" -- Message

Config.vest = 2  -- VEST 1

Config.vest2 = 0  -- VEST 2

-- Normal protective vest

Config.notifications2 = true

Config.Title2 = "D_Vestsystem" -- Message Title

Config.Message2 = "Normal-Vest Successfully used" -- Message

Config.vest3 = 12  -- VEST 1

Config.vest4 = 1   -- VEST 2

-- Heavy protective vest

Config.notifications3 = true

Config.Title3 = "D_Vestsystem" -- Message Title

Config.Message3 = "Heavy-Vest Successfully used" -- Message

Config.vest5 = 12  -- VEST 1

Config.vest6 = 1   -- VEST 2